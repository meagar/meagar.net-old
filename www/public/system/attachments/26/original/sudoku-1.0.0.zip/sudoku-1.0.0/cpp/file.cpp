
#include "file.hpp"

mne::io::iconfstream::iconfstream() {

}

mne::io::iconfstream::iconfstream(const std::string& file)
: fin_(file.c_str()) {

}

mne::io::iconfstream::~iconfstream() {

}

void mne::io::iconfstream::eat_line_() {
	char ch;
	while (peek_(ch) && ch != '\n')
		get_(ch);
}

void mne::io::iconfstream::eat_whitespace_() {
	char ch;
	while (peek_(ch) && std::isspace(ch))
		get_(ch);
}

bool mne::io::iconfstream::read(std::string& out) {
	eat_whitespace_();

	char ch = peek_();
	if (ch != '"') {
		fin_ >>
		
}

