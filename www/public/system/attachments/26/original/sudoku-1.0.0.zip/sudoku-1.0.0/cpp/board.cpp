/**
 * @file   board.cpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 28 / 2006
 *
 * definitions for mne::sudoku::Board
 * 
 */

#include "board.hpp"
#include "space.hpp"
#include "set.hpp"

#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <algorithm>

// Create a traditional 9x9 sudoku game
/*mne::sudoku::Board::Board()
: width_(9), height_(9), nums_(9) {
	spaces_.resize(width_ * height_);
}*/


mne::sudoku::Board::Board(const std::string& gameFile)
: width_(0), height_(0), nums_(0) {
	std::ifstream fin(gameFile.c_str());
	if (!fin)
		throwEx(sudoku::exception, "Error opening data file");

	// Read the width and height of the board
	fin >> width_ >> height_ >> nums_;
	nums_ += 1;

	spaces_.reserve(width() * height());
	grid_.resize(width_, std::vector<mne::sudoku::Space*>(height(), 0));

	char ch;
	for (std::size_t y = 0; y < height(); ++y) {
		for (std::size_t x = 0; x < width(); ++x) {
			if (!(fin >> ch)) {
				assert(false); // todo
			}
			switch (ch) {
			case '0': // space
				spaces_.push_back(mne::sudoku::Space());
				grid_[x][y] = &spaces_.back();
				break;
			case '.':
				grid_[x][y] = 0;
				// nothing
				break;
			default:
				assert (false);
			}
		}
	}

	// Read the number of sets
	std::size_t i;
	if (!(fin >> i))
		throwEx(sudoku::exception, "Not able to read the number of sets");

	sets_.resize(i, mne::sudoku::Set(nums_));

	// Read in the groupings
	for (SpaceItr it = spaces_.begin(); it != spaces_.end(); ++it) {
		while (fin >> i) {
			i -= 1; // adjust to 0-based index

			if (i >= sets_.size())
				throwEx(sudoku::exception, "Invalid set index in data file");
				
			it->addSet(&sets_[i]);

			ch = fin.peek();
			if (ch == ',') {
				fin.get(ch);
			} else {
				break;
			}
		}
	}
}

mne::sudoku::Board::~Board() {

}

// Private
bool mne::sudoku::Board::checkBounds_(std::size_t x, std::size_t y) const {
	return (x >= 0 && x < grid_.size()) && (y >= 0 && y< grid_[x].size());
}

std::size_t mne::sudoku::Board::getSpace(std::size_t x, std::size_t y) const {
	if (checkBounds_(x,y))
		return grid_[x][y]->getValue();
	return 0;
}

bool mne::sudoku::Board::setSpace(std::size_t x, std::size_t y, std::size_t v) {
	if (checkBounds_(x,y)
	&& grid_[x][y] && !grid_[x][y]->isFixed()) {
		grid_[x][y]->setValue(v);	
		return true;
	}

	return false;
}

std::ostream& mne::sudoku::Board::print(std::ostream& os) const {
	for (std::size_t y = 0; y < height(); ++y) {
		for (std::size_t x = 0; x < width(); ++x) {
			if (isSpace(x,y)) {
				os << getSpace(x,y) << ' ';
			} else {
				os << ". ";
			}
		}
		os << '\n';
	}

	return os;
}

bool mne::sudoku::Board::complete() const {
	for (ConstSetItr it = sets_.begin(); it != sets_.end(); ++it) {
		if (!it->complete())
			// one of our sets is incomplete, the whole board is incomplete
			return false;
	}

	// no invalid sets, the board is complete
	return true;
}

bool mne::sudoku::Board::invalid() const {
	for (ConstSetItr it = sets_.begin(); it != sets_.end(); ++it) {
		if (it->invalid())
			// one of our sets is invalid, so the whole board is invalid
			return true;
	}

	// no invalid sets, we're /not/ invalid
	return false;
}

void mne::sudoku::Board::clear() {
	for (SpaceItr it = spaces_.begin(); it != spaces_.end(); ++it)
		it->clear();
}

void mne::sudoku::Board::reset() {
	for (SpaceItr it = spaces_.begin(); it != spaces_.end(); ++it)
		it->setValue(0); // fails for fixed spaces
}

/*
void mne::sudoku::Board::loadState(const std::string& stateFile) {
	clear();

	std::ifstream fin(stateFile.c_str());
	std::size_t i;
	if (!fin)
		throwSudokuEx("Error opening game state file");

	for (SpaceItr it = spaces_.begin(); it != spaces_.end(); ++it) {
		if (fin >> i) {
			if (i)
				(*it)->fixValue(i);
		} else {
			throwSudokuEx("Error loading game state");
		}
	}
}
*/

int mne::sudoku::Board::solve_(std::vector< mne::sudoku::Space*>& spaces
, std::size_t idx, bool solve) {
	if (idx >= spaces.size())
		return (int)complete();

	int n = 0;
	for (std::size_t i = 1; i < numbers(); ++i) {
		if (spaces[idx]->testValue(i)) {
			spaces[idx]->setValue(i);
			n += solve_(spaces, idx + 1, solve);
		}
	}

	if (n == 0 || !solve)
		spaces[idx]->clear();

	return n;
}

int mne::sudoku::Board::numSolutions() {
	// TODO
	return 0;
}

void mne::sudoku::Board::solve() {
	// Reset the board to it's not-user-modified state
	reset();

	// Get a list of all the spaces who's values aren't fixed.
	std::vector<mne::sudoku::Space*> s;	
	s.reserve(spaces_.size());

	// Build a list of all the non-fixed spaces
	for (SpaceItr it = spaces_.begin(); it != spaces_.end(); ++it) {
		// If a space isn't fixed, reset it's value and add it to the list
		if (!it->isFixed())
			s.push_back(&(*it));
	}

	if (solve_(s, 0) != 1)
		throwEx(sudoku::exception, "Error solving board");
}

bool mne::sudoku::Board::makeGame_(SpaceList& s, std::size_t idx) {
	if (idx >= s.size())
		return complete();

	typedef std::vector<std::size_t> ValueList;
	ValueList values;	
	values.reserve(numbers());

	// find which numbers this space can use
	for (std::size_t i = 1; i < numbers(); ++i) {
		if (s[idx].testValue(i))
			values.push_back(i);	
	}

	// We have no valid values for this space, return up the stack
	if (values.size() == 0)
		return false;

	// Shuffle the list of spaces
	std::random_shuffle(values.begin(), values.end());

	for (ValueList::iterator it = values.begin(); it != values.end(); ++it) {
		// We try each value, and then recurse to the next space
		// If it returns true, then this is a valid space (over all)
		// and we can return true, indicating we are also valid
		// If the next space returns false, this value leads to an
		// unsolvable board, and we have to return false.
		s[idx].setValue(*it);
		if (makeGame_(s, idx + 1))
			return true;
	}

	// We didn't find any valid values, unset ourselves and return false
	s[idx].clear();

	return false;
}

void mne::sudoku::Board::makeGame(unsigned int gameNo, unsigned int skill) {
	assert (skill >= 1 && skill <= 10);
	clear();

	srand (gameNo ? gameNo : time(0));

	// Generate a random complete board
	makeGame_(spaces_, 0);

	// Decide how many spaces should be revealed
	int n = (int)((0.25f + (((10.0f - (float)skill)) / 50.0f)) * spaces_.size());

	int numLeft = spaces_.size() + 1;

	// Remove spaces until we have n left
	while (numLeft > n) {
		int idx = (int)(((float)std::rand() / (float)RAND_MAX) * numLeft);
		static SpaceItr it;
		for (it = spaces_.begin(); it != spaces_.end(); ++it) {
			if (it->getValue()) {
				// We've found a not-already-removed space
				--idx;
				if (idx <= 0)
					break;
			}
		}

		it->clear();

		--numLeft;
	}

	// Fix the remaining values
	for (SpaceItr it = spaces_.begin(); it != spaces_.end(); ++it) {
		if (it->getValue())
			it->fix();
	}
}

