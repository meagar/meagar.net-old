
#ifndef GUARD_mne_sudoku_board_hpp_
#define GUARD_mne_sudoku_board_hpp_

/**
 * @file   board.hpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 28 / 2006
 *
 * Declares mne::sudoku::Board
 * Board is the main controlling class which
 *  - generates games
 *  - saves and restores game states
 *  - solves games
 *
 */

#include "space.hpp"
#include "error.hpp"

#include <vector>
#include <map>
#include <string>

//-----------------------------------------------------------------------------
namespace mne { namespace sudoku {
//-----------------------------------------------------------------------------

class Board {
public:
	Board();
	Board(const std::string& gameFile);
	~Board();

	void loadGame(const std::string& gameFile);
	
	/// Return the (maximum) width of the board, in spaces
	inline std::size_t width() const { return width_; }

	/// Return the (maximum) height of the board, in spaces
	inline std::size_t height() const { return height_; }

	/// Return the numbers available for use
	inline std::size_t numbers() const { return nums_; }

	/// Return true if the space at x,y is a place to put values
	inline bool isSpace(std::size_t x, std::size_t y) const {
		assert (0 < x && x < width() && 0 < y && y < height());
		return grid_.at(x).at(y) != 0;
	}

	/** @brief Return the current value of the space at a given position
	 *
	 *  @param x The x position of the space to retreive
	 *  @param y The y position of the space to retreive
	 *
	 *  @return The value of the space at the given x,y position
	 */
	std::size_t getSpace(std::size_t x, std::size_t y) const;

	/** @brief Set the value of a space at a given position
	 *
	 *  @param x The x position of the space to retreive
	 *  @param y The y position of the space to retreive
	 *  @param v the value to set the space at x,y to
	 *  
	 *  @return True if the given value can be accepted by the given space
	 *          (it's value isn't fixed, and the coords are valid).  False
	 *          otherwise.
	 *
	 *  @note Throws a SudokuException if the given x,y position is invalid
	 */
	bool setSpace(std::size_t x, std::size_t y, std::size_t v);

	// Return true if the board is complete and correct
	bool complete() const;

	// Return true if one or more spaces on the board are invalid
	bool invalid() const;


	// Clear the board - every space will be blank
	void clear();

	// Reset the board (clear all non-fixed spaces)
	void reset();

	/// Generate a new gameboard
	/// @param skill an integer between 1 and 10, determining the relative skill
	///        of the board (1 is easies, 10 is hardest)
	void makeGame(unsigned int gameNo, unsigned int skill);

	// Load a saved state
	// All values loaded will be considered fixed
	bool loadState(std::ostream& os);

	// Save the current state to a file
	bool saveState(std::ostream& os);


	// Solve the board from it's initial state
	// (Reset the board so that only fixed values are present, and then solve)
	void solve();

	// Return the number of solutions to the board in it's current state
	// For generated boards, which are guaranteed to have unique solutions
	// will always return 1 (or 0 if the user has made a wrong move)
	int numSolutions();

	// Print the board to the given output stream
	std::ostream& print(std::ostream& os = std::cout) const;

private:
	// space-saving typedefs
	typedef std::vector<mne::sudoku::Space> SpaceList;
	typedef SpaceList::iterator SpaceItr;
	typedef SpaceList::const_iterator ConstSpaceItr;
	
	typedef std::vector<mne::sudoku::Set> SetList;
	typedef SetList::iterator SetItr;
	typedef SetList::const_iterator ConstSetItr;

	// Return true if the given coordinates are a valid place to put a number
	bool checkBounds_(std::size_t x, std::size_t y) const;

	// The recursive component of the solving algorithm
	int solve_(std::vector<mne::sudoku::Space*>& vec
		, std::size_t idx, bool leaveSolved = true);

	// Build a new game board
	bool makeGame_(SpaceList& vec, std::size_t idx);

	// The list of sets which must all be valid before the board is
	// considered valid
	SetList sets_;
	
	// Used to solve the board
	SpaceList spaces_;

	std::vector< std::vector< mne::sudoku::Space* > > grid_;

	/// Stores the maximum width of the board
	std::size_t width_;

	/// Stores the maximum height of the board
	std::size_t height_;

	/// The number of digits in the game (typically 1..9)
	std::size_t nums_;
}; // class Board


/**
 * Ostream operators
 * @{
 */
inline std::ostream& operator<<(std::ostream& os
, const mne::sudoku::Board& b) {
	return b.print(os);
}

/** @} */

//-----------------------------------------------------------------------------
} } // namespace sudoku, am
//-----------------------------------------------------------------------------

#endif //GUARD_mne_sudoku_board_hpp_

