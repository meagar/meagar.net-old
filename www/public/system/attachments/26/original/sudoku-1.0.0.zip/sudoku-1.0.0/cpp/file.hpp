
#ifndef GUARD_mne_sudoku_file_hpp__
#define GUARD_mne_sudoku_file_hpp__

#include <iostream>
#include <fstream>
#include <string>

//----------------------------------------------------------------------------
namespace mne { namespace io {
//----------------------------------------------------------------------------

class ConfIStream {
public:
	iconfstream();
	iconfstream(const std::string& filename);
	~iconfstream();

	void open(const std::string& filename);
	void close();

	template <typename T> bool read(T& out) {
		std::cerr << "read(T)" << std::endl;
		fin_ >> out;
		return fin_.good();
	}

	bool read(std::string& out);

	inline operator bool() { return fin_.good(); }

	const std::string& file();
	std::size_t line();
private:

	void eat_whitespace_();
	void eat_line_();

	bool peek_(char&);
	bool get_(char&);
	void put_(char);

	std::ifstream fin_;
	std::size_t line_;
};

template <typename T> ConfigFileReader& operator >> (ConfigFileReader& r, T& out) {
	r.read(out);
	return r;
}

//----------------------------------------------------------------------------
} } // namespace io, mne
//----------------------------------------------------------------------------

#endif //GUARD_mne_sudoku_file_hpp__

