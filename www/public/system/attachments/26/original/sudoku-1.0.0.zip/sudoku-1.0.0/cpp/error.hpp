
#ifndef GUARD_mne_sudoku_error_hpp_
#define GUARD_mne_sudoku_error_hpp_

/**
 * @file   error.hpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 31 / 2006
 */

#define throwEx(type, message)\
	throw mne::sudoku::Exception(message, __FILE__, __LINE__)

//-----------------------------------------------------------------------------
namespace mne { namespace sudoku {
//-----------------------------------------------------------------------------

class Exception {
public:
	/// @brief Create a new exception
	///
	/// @param what A short, descriptive error message for use in debugging
	/// @param file The file in which this exception is being thrown, __FILE__
	/// @param line The line on which this exception is being thrown, __LINE__
	Exception(const char* what, const char* file, int line)
		: what_(what), file_(file), line_(line) { }

	/// @brief Return an error message describing what happened
	///
	/// @return A c-style string containing an error message
	inline const char* what() const { return what_; }

	/// @brief Return the file in which the exception was thrown
	///
	/// @return A c-style string containing a filename
	inline const char* file() const { return file_; }

	/// @brief Return the line on which the exception was thrown
	///
	/// @return An integer containing a line number
	inline int line() const { return line_; }

private:
	const char* what_; /// @< user-readable error message
	const char* file_; /// @< __FILE__ in which error occured
	int line_;         /// @< __LINE__ on which line occured

}; // class Exception

//-----------------------------------------------------------------------------
} } // namespace sudoku, mne
//-----------------------------------------------------------------------------

#endif // GUARD_mne_sudoku_error_hpp_

