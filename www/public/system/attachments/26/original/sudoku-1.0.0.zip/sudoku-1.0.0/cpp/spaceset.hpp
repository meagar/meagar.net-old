
#ifndef GUARD_mne_sudoku_spaceset_hpp_
#define GUARD_mne_sudoku_spaceset_hpp_

/**
 * @file   spaceset.hpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 16 / 2007
 *
 */

#include "space.hpp"
#include "error.hpp"

#include <vector>
#include <map>
#include <string>

//-----------------------------------------------------------------------------
namespace mne { namespace sudoku {
//-----------------------------------------------------------------------------

class SpaceSet {
public:
	SpaceSet(int numbers, int numSpaces, int numSets)
	: numbers_(numbers) {
	}

	~SpaceSet() {

	}

	// Return true if the board is valid
	bool isValid() const {

	}

	// Return true if placing a space at a given index is valid
	bool isValid(int num, int idx) const {

	}

	mne::sudoku::Set& set(std::size_t i) {
		assert (i < sets_.size());
		return sets_[i];
	}

	mne::sudoku::Space& space(std::size_t i) {
		assert (i < spaces_.size());
		return spaces_[i];
	}

	std::size_t numSpaces();
	std::size_t numSets();

private:

	// space-saving typedefs
	typedef std::vector<mne::sudoku::Space> SpaceList;
	typedef SpaceList::iterator SpaceItr;
	typedef SpaceList::const_iterator ConstSpaceItr;
	
	typedef std::vector<mne::sudoku::Set> SetList;
	typedef SetList::iterator SetItr;
	typedef SetList::const_iterator ConstSetItr;


	SetList sets_;
	SpaceList spaces_;

};

//-----------------------------------------------------------------------------
} } // namespace sudoku, mne
//-----------------------------------------------------------------------------

#endif // GUARD_mne_sudoku_spaceset_hpp_

