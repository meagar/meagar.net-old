
/**
 * @file   set.cpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 28 / 2006
 */

#include "set.hpp"

#include <cassert>

bool mne::sudoku::Set::complete() const {
	for (std::size_t i = 1; i < values_.size(); ++i)
		if (values_[i] != 1)
			return false;
	
	return true;
}

bool mne::sudoku::Set::invalid() const {
	for (std::size_t i = 1; i < values_.size(); ++i)
		if (values_[i] >= 2)
			return true;

	return false;
}

void mne::sudoku::Set::addValue(std::size_t v) {
	assert(v >= 0 && v < values_.size());
	++values_[v];
}

// Delete a value from our values array
void mne::sudoku::Set::delValue(std::size_t v) {
	assert (v >= 0 && v < values_.size());
	--values_[v];
}

// Return true if this set has the given value in it.
bool mne::sudoku::Set::hasValue(std::size_t v) const {
	assert (v >= 0 && v < values_.size());
	return values_[v] >= 1;
}

