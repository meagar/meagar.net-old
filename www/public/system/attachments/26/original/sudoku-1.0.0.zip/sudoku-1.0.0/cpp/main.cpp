
#include "board.hpp"

// For command line argument parsing
#include <unistd.h>
#include <getopt.h>

#include <cstdlib>
#include <sstream>
#include <iostream>

//-----------------------------------------------------------------------------
namespace cli {
//-----------------------------------------------------------------------------

bool solve = false;
unsigned int gameNo = 0;
unsigned int difficulty = 5;

void setBoardNo(const char* str) {
	std::istringstream in(str);
	if (!(in >> cli::gameNo)) {
		std::cerr << "Invalid game number" << std::endl;
		std::exit(1);
	}
}

void setDifficulty(const char* str) {
	std::istringstream in(str);
	if (!(in >> cli::difficulty)
	|| (difficulty < 1 || difficulty > 10)) {
		std::cerr << "Invalid difficulty" << std::endl;
		std::exit(1);
	}
}

void help() {
	std::cout << "\t Usage : sudoku [OPTIONS]\n"
		<< "\t-g, --game N              Start game #N (seed the random number generator)\n"
		<< "\t-d, --difficulty [1..10]  Choose the difficulty of the game.  Determines\n"
		<< "                            how much of the board is hidden.\n"
		<< "\t-s, --solve               Solve the given game number\n"
		<< "\t-h, --help                Show this message.\n"
		<< std::endl;
	std::exit(0);
}

void parseArgs(int argc, char** argv) {
	static struct option longOpts[] = 
		{ { "game",       1, 0, 'g' }
		, { "difficulty", 1, 0, 'd' }
		, { "solve",      0, 0, 's' }
		, { "help",       0, 0, 'h' }
		, { 0, 0, 0, 0 }
		};

	static const char* shortOpts = "g:d:sh";

	while (1) {
		switch (getopt_long(argc, argv, shortOpts, longOpts, 0)) {
		case 'g': // select a given game
			cli::setBoardNo(optarg);
			break;
		case 's': // solve a given board
			cli::solve = true;
			break;
		case 'd':
			cli::setDifficulty(optarg);
			break;
		case 'h': // show help
			cli::help();
			break;
		case '?': // unknown option
			break;
		case -1:
			return;
		default:
			abort();
		}
	}
} // void parseArgs

//-----------------------------------------------------------------------------
} // namespace mne, cli, sudoku
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
namespace ui {
//-----------------------------------------------------------------------------

// This only works with a 9x9 board
void printBoard(const mne::sudoku::Board& b) {

	const std::string NUMS = "     1   2   3   4   5   6   7   8   9\n";
	const std::string HDIV = "   +===========+===========+===========+\n";
	const std::string LDIV = "   |---+---+---+---+---+---+---+---+---|\n";

	std::cout << NUMS;

	for (std::size_t y = 0; y < 9; ++y) {

		std::cout << (y % 3 ? LDIV : HDIV); 
		std::cout << ' ' << y + 1 << ' ';

		for (std::size_t x = 0; x < 9; ++x) {
			std::cout << (x % 3 ? ':' : '|') << ' ';

			// Get the value at the current coords
			std::size_t space = b.getSpace(x,y);

			// If it's non-zero print it, if it's zero print a blank
			if (space)
				std::cout << space;
			else
				std::cout << ' ';
			std::cout << ' ';
		}

		 std::cout << "| " << y + 1 << std::endl;
	}

	std::cout << HDIV << NUMS;
}

void pause() {
	std::cout << "\nPress return to continue." << std::endl;

	std::cin.clear();
	std::cin.get();
}

/// @brief Show a message and wait for a y/n response
bool prompt(const std::string& message) {
	std::cout << message << "\n(y/n) >> " << std::endl;
	std::string answer;
	std::getline(std::cin, answer);
	return answer == "y";
}

// Show available UI commands
void showHelp() {
	std::cout << "Available commands:\n"
	          << "\t quit,q    - Quit Sudoku\n"
	          << "\t help,h,?  - Show this message\n"
	          << "\t solve,s   - Solve the current board\n"
	          << "\t reset,r   - Reset the board to the initial state\n"
	          << "\n"
	          << "\t To move, enter the x and y coordinates, followed by the number to place.\n"	
	          << std::endl;

	pause();
}

// Returns true if the game should continue, false to quite
void playGame(int gameNo, int difficulty) {
	// Create our board
	static const std::string DATA_FILE = "data/9x9.dat";
	mne::sudoku::Board b(DATA_FILE);

	b.makeGame(gameNo, difficulty);

	std::cout << "Game #" << gameNo << '\n' << std::endl;	

	if (cli::solve) {
		// --solve, just solve the game and exit
		b.solve();
		printBoard(b);
		return;
	}

	std::string cmd;
	for (;;) {
		printBoard(b);
		int x, y, v;
		std::cout << "(? for help) > ";

		// Try to read x,y coords and value
		if (std::cin >> x >> y >> v) {
			// Attempt to set value on board
			if (!b.setSpace(x - 1, y - 1, v))
				std::cout << "Invalid move" << std::endl;
		} else {
			// Read of integer coords failed, try parsing as command
			std::cin.clear();
			std::cin >> cmd;
			std::cin.get();
			if (cmd == "solve" || cmd == "s") {
				// SOLVE
				if (prompt("Solve the current board?")) {
					b.solve();
					printBoard(b);
					return;
				}
			} else if (cmd == "help" || cmd == "h" || cmd == "?") {
				// HELP
				showHelp();
			} else if (cmd == "reset" || cmd == "r") {
				// RESET
				if (prompt("Reset board to initial state?")) {
					std::cout << "Board reset." << std::endl;
					b.clear();
				}
			} else if (cmd == "quit" || cmd == "q") {
				// QUIT
				if (prompt("Quit game, discarding board?"))
					return;
			} else {
				std::cout << "Unknown command: " << cmd << "\n";
			}
		}

		if (b.complete()) {
			std::cout << "complete" << std::endl;
			return;
		}
	}
}

//-----------------------------------------------------------------------------
} //namespae ui
//-----------------------------------------------------------------------------

int main(int argc, char** argv) {

	cli::parseArgs(argc, argv);

	// If no game number chosen, use random
	if (cli::gameNo == 0)
		cli::gameNo = time(0);

	ui::playGame(cli::gameNo, cli::difficulty);
}

