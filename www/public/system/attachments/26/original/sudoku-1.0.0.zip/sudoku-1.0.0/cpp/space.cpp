
/**
 * @file   space.cpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 28 / 2006
 */


#include "space.hpp"

#include <iostream>
#include <cmath>
#include <cassert>

typedef std::vector<mne::sudoku::Set*> vec;

void mne::sudoku::Space::setValue(std::size_t v) {
	if (isFixed())
		return;

	// Delete our old value from our sets, and add our new value
	for (vec::iterator it = sets_.begin(); it != sets_.end(); ++it) {
		(*it)->delValue(value_);
		(*it)->addValue(v);
	}

	value_ = v;
}

void mne::sudoku::Space::fixValue(std::size_t v) {
	setValue(v);
	setFixed(true);
}

void mne::sudoku::Space::clear() {
	setValue(0);
	setFixed(false);
}

bool mne::sudoku::Space::testValue(std::size_t v) const {
	for (vec::const_iterator it = sets_.begin(); it != sets_.end(); ++it)
		if ((*it)->hasValue(v))
			return false;

	return true;
}

