
#ifndef GUARD_mne_sudoku_set_hpp_
#define GUARD_mne_sudoku_set_hpp_

/**
 * @file   set.hpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 28 / 2006
 */

#include <iostream>
#include <vector>

//-----------------------------------------------------------------------------
namespace mne { namespace sudoku {
//-----------------------------------------------------------------------------

class Set {
public:
	Set(std::size_t size) : values_(size, 0) { }
	~Set() { }
	
	/** @brief Check to see if the set of spaces is complete and valid - it
	 *         has exactly one of each value, with no duplicates
	 *
	 *  @return True if the set is complete, false otherwise
	 */
	bool complete() const;

	/** @brief Return true if the set is invalid, that is the same number is used
	 *         twice in the same set.
	 *
	 *  @return True if the set is invalid, false otherwise
	 */
	bool invalid() const;

	// Add a value to our values array
	void addValue(std::size_t v);

	// Delete a value from our values array
	void delValue(std::size_t v);

	// Return true if this set has the given value in it.
	bool hasValue(std::size_t v) const;

	inline void setNumber(int i) { number_ = i; }
	inline int getNumber() const { return number_; }

private:
	int number_;
	std::vector<int> values_;

}; // class Set

//-----------------------------------------------------------------------------
} } // namespace sudoku, mne
//-----------------------------------------------------------------------------

#endif // GUARD_mne_sudoku_set_hpp_

