#ifndef GUARD_mne_sudoku_space_hpp_
#define GUARD_mne_sudoku_space_hpp_

/**
 * @file   space.hpp
 * @author Matthew Eagar
 * @author meagar@gmail.com
 * @date   July 28 / 2006
 */

#include "set.hpp"

#include <cassert>
#include <iostream>
#include <vector>

//-----------------------------------------------------------------------------
namespace mne { namespace sudoku {
//-----------------------------------------------------------------------------

class Space {
public:
	/// @brief Create a new space with no value
	Space() : value_(0), fixed_(false) { }

	/// @brief Add a new set to our list of sets
	///
	/// @param s A pointer to the mne::sudoku::set to add
	inline void addSet(mne::sudoku::Set* s) { sets_.push_back(s); }

	/// @brief Test a given value to see if it is valid
	///
	/// @param val A value to test
	///
	/// @return True if this space can accept the value without creating an
	///         invalid game state, false otherwise
	bool testValue(std::size_t val) const;

	/// @brief Return the current value of this space
	///	
	/// @return The value of this space
	inline std::size_t getValue() const { return value_; }

	/// @brief Set the current value of this space to a new value
	///
	/// @param value The value to set this space to
	void setValue(std::size_t value);

	/// @brief Set the current value of this space to a new value, and set
	///        it's state to 'fixed' so it cannot be changed
	///
	/// @param value the value to set this space to
	///
	/// @note Calls to isFixed() will return true until clear() is called
	void fixValue(std::size_t value);

	/// @brief Return the fixed state of this space
	///
	/// @return True if this space is fixed, false otherwise
	inline bool isFixed() const { return fixed_; }

	/// @brief Set our state to fixed
	inline void setFixed(bool fixed) {
		assert (value_ || fixed == false);
		fixed_ = fixed;
	}

	/// @brief Assigned of a scalar value
	inline Space& operator=(std::size_t value) {
		setValue(value);
		return *this;
	}
	
	/// @brief Convert to a scalar value
	inline operator std::size_t () {
		return getValue();
	}

	/// @brief Set this space's fixed state to 'fixed'
	inline void fix() { setFixed(true); }

	/// @brief Clear this space's value and fixed state
	///
	/// @note getValue() will return 0, and isFixed() will return false
	void clear();

	/// @brief Check to see if this space currently holds a valid value
	///
	/// @return True if this space's value is currently valid, meaning that
	///         none of the sets it belongs to contain a duplicate value
	bool isValid();

	/// @brief Return true if our value is equal to a given value
	///	
	/// @note s == v is the same as s.getValue() == v
	inline bool operator==(std::size_t v) { return value_ == v; }

	/// @brief Return true if our value is not equal to a given value 
	inline bool operator!=(std::size_t v) { return value_ != v; }

private:
	/// Sets to which this space belongs
	std::vector<mne::sudoku::Set*> sets_; 

	/// The value of this space
	std::size_t value_;

	/// Whether or not this value is fixed
	bool fixed_;

}; // class Space

//-----------------------------------------------------------------------------
} } // namespace sudoku, mne
//-----------------------------------------------------------------------------

#endif //GUARD_mne_sudoku_space_hpp_

